#Node.js socket server sample
A Sample Node.js socket server using socket.io package

# Pre-req

- Node.js

# Starting the server

Run below command in root folder
`npm i`
`node app.js`

Socket server runs on port 3001
http server runs on port 3000
